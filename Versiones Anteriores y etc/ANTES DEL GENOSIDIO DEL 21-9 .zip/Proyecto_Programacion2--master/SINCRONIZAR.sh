#!/bin/bash
git fetch
git merge origin/master