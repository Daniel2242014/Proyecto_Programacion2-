package logica;


public class Juez {
    
}
