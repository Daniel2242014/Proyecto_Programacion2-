package logica;

public class Datos {
    
}
