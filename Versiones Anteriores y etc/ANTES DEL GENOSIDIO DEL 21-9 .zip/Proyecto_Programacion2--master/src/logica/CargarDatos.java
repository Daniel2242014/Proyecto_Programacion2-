package logica;

public class CargarDatos {
    
}
