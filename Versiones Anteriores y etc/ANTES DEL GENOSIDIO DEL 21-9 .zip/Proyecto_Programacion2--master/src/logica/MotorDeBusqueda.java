package logica;


public class MotorDeBusqueda {
    
}
