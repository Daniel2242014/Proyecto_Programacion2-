package logica;


public class Estadio {
    
}
