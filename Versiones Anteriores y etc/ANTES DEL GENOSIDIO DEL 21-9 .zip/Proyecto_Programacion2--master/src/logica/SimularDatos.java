package logica;

public class SimularDatos {
    
}
