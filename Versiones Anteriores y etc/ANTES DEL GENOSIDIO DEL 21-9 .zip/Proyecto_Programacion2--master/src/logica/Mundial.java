package logica;


public class Mundial {
    
}
