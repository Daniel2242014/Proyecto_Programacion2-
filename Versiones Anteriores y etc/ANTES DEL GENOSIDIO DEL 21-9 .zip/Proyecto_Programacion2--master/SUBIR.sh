#!/bin/bash
git add .
git commit -m"Cambio"
git push origin master