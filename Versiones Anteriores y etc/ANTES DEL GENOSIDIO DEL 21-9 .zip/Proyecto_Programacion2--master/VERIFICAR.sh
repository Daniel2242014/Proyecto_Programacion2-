#!/bin/bash
git status
read -rsp $'Press any key to continue...\n' -n 1 key